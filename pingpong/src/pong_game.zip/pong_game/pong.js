var vx;
var vy;
var dt = 1;    
var ball_present_x;
var ball_present_y;
var page_y;
var paddle;
var stoploop;
var strikes;
var maxscore=0;
var velocity=20;
let random_angle;
var paddle_height;



function get_random_num(max, min)
{
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
function initialize() {

    console.log("calling initialize")  
    document.getElementById("ball").style.top = get_random_num(250,0)+'px'; // assigning random initial position for the ball
    document.getElementById("ball").style.left = "0px";
    paddle = document.getElementById("paddle");
    paddle_height = paddle.getBoundingClientRect().height;

    random_angle = get_random_num(45,-45)* (Math.PI/180)//radians

    vx= velocity * Math.cos(random_angle);
    vy= velocity * Math.sin(random_angle);

    if(strikes > maxscore)
    maxscore = strikes;
    document.getElementById("score").innerHTML = maxscore;
    document.getElementById("strikes").innerHTML = 0;
    strikes = 0;

  }
  function resetGame()
  {
    document.getElementById("strikes").innerHTML = strikes = 0;
    document.getElementById("score").innerHTML = maxscore = 0;
    document.getElementsByName('speed')[0].checked = true;
    dt = 1;
    initialize();
    clearInterval(stoploop);
  }
  function setSpeed(speed)
  {
     
    (speed == "0")?dt = 1 : (speed == "1")?dt = 1.5 : dt = 2;
     
  }

  function startGame()
  {        
    clearInterval(stoploop);  //Handling a negativecase where user clicks on start multiple times when game is on
    stoploop = setInterval(moveball,100) //100 miliseconds
  }

  function moveball()
  {
         
    var ball = document.getElementById("ball");
    var bwidth = ball.getBoundingClientRect().width;
    var pleft =  paddle.getBoundingClientRect().left;
    var ball_paddle = pleft-bwidth-10; //ball touches paddle at this point 785(paddle left)-20(ball width) = 765 -10 (kind of offset)
    var court_left = court.getBoundingClientRect().left;// court left = 8

    ball_present_x = parseInt(ball.style.left)+vx*dt; 
    ball_present_y = parseInt(ball.style.top)+vy*dt;


    if(ball_present_y > 399 ) //bouncing at the bottom border
    {
      vy = -vy;
      ball_present_y = 2*399-ball_present_y;
    }
    else if(ball_present_y < -86) // bouncing at the top border
    {
      vy = -vy;
      ball_present_y = 2*(-86)-ball_present_y;
    }
    else if(ball_present_x >= ball_paddle ) // bouncing at the paddle/right border
    {
      var ptop = parseInt(paddle.style.top)-82; //-82 is top for ball but 0 is top for paddle!, offsetting here 

      if((ptop <=  ball_present_y+ball.height/2) && ball_present_y <= ptop+paddle_height) //if ball is hit : ball should hit in between paddle top and paddle bottom
      {
        vx = -vx;
        ball_present_x = 2*ball_paddle-ball_present_x;
        strikes++;
      }
      else // if ball has missed the strike
      {
        initialize();
        clearInterval(stoploop);
        return;
      }
      
    }
    else if(ball_present_x < court_left-13) //left border bouncing  : court_left(8)-13 (fine tuning)
    {
      vx = -vx;
      ball_present_x = 2*(court_left-13)-ball_present_x;
    }

    ball.style.left  = ball_present_x+'px';
    ball.style.top   = ball_present_y+'px';
    document.getElementById("strikes").innerHTML = strikes;

  }


  function movePaddle(event)
  {
    paddle = document.getElementById("paddle"); 
    page_y = event.pageY;
    var court_top = court.getBoundingClientRect().top;
    var court_bottom = court.getBoundingClientRect().bottom;
   
    //if( page_y >=court_top && page_y<=court_bottom-paddle_height) //this logic does not work if the mouse is moved fast
    //  paddle.style.top = page_y-court_top+'px';
	  
	  if( page_y >=court_top-(paddle_height/2) && page_y<=court_bottom+(paddle_height/2)-6)//paddle movement : court top till court bottom
    {
	    if((page_y-court_top+paddle_height)>500)
		     paddle.style.top = (court_bottom-court_top)-6 - paddle_height+'px'; // if paddle moves out of the bottom boundary, subtracting paddle height
	    else if( (page_y-court_top) < 0) 
		     paddle.style.top =0+'px';  //if paddle tries to move above the top boundary, setting it its 0 position
	    else 
         paddle.style.top = page_y-court_top+'px'; // pagey will give cordinates w.r.t page, so we will offset it by subtracting courtop
    }   

  }